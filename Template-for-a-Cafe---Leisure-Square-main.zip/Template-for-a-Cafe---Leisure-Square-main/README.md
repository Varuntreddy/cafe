# Template-for-a-Cafe---Leisure-Square

# Frontend:
HTML
CSS
JAVASCRIPT

# Backend:
PHP
MYSQL

# Prerequisites:
Download and Setup XAMPP Web Server Tool in your Local Device.
